public class Dependencies {
    public static var central: BluetoothCentral = {
        FlipperCentral()
    }()
}
