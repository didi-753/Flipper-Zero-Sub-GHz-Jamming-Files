enum Limits {
    // NOTE: not used yet
    // static var maxPBPacket: Int { 1536 }
    static var maxPBStorageFileData: Int { 512 }
}
