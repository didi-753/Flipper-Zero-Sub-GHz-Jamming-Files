import XCTest

@testable import Peripheral

class PeripheralTests: XCTestCase {
    func testEquatable() {
        XCTAssertEqual(42, 42)
    }
}
