import Core
import SwiftUI

// swiftlint:disable vertical_parameter_alignment_on_call

struct SpeedTestView: View {
    // next step
    @StateObject var speedTest: SpeedTest = .init(
        pairedDevice: Dependencies.shared.pairedDevice
    )
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack {
            Spacer()
            Text(String("\(speedTest.bps) bytes per second"))
            Spacer()
            Text(String("\(speedTest.bpsMin) ~ \(speedTest.bpsMax) bps"))
            Spacer()
            Text("Packet size: \(Int(speedTest.packetSize))")
            Slider(
                value: $speedTest.packetSize,
                in: (1.0 ... Double(speedTest.maximumPacketSize)),
                step: 1.0
            ) {
                Text("Packet size")
            } minimumValueLabel: {
                Text("1")
            } maximumValueLabel: {
                Text(String(speedTest.maximumPacketSize))
            }
            Spacer()
            Button(speedTest.isRunning ? "Stop" : "Start") {
                switch speedTest.isRunning {
                case true:
                    speedTest.stop()
                case false:
                    speedTest.start()
                }
            }
            .padding(.bottom, 50)
        }
        .padding(14)
        .navigationBarBackButtonHidden(true)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            LeadingToolbarItems {
                BackButton {
                    dismiss()
                }
                Title("Speed Test")
            }
        }
        .onDisappear {
            speedTest.stop()
        }
    }
}
