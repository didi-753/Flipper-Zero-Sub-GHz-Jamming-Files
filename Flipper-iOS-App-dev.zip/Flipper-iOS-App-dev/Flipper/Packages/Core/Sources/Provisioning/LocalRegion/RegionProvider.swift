public protocol RegionProvider {
    var regionCode: ISOCode? { get }
}
