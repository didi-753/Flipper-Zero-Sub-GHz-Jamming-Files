import Logging

let logger = Logger(label: "Core")
