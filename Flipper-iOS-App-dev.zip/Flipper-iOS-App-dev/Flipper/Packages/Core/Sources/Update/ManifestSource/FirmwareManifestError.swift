enum FirmwareManifestError: Swift.Error {
    case channelNotFound
    case targetNotFound
    case bundleNotFound
}
