public protocol DeviceStorage {
    var flipper: Flipper? { get set }
}
