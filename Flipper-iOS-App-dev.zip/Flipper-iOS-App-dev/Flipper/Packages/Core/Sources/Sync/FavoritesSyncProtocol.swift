protocol FavoritesSyncProtocol {
    func run() async throws
}
