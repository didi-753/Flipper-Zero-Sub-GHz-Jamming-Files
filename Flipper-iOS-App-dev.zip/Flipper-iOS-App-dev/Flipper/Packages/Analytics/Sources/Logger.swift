import Logging

let logger = Logger(label: "Analytics")
