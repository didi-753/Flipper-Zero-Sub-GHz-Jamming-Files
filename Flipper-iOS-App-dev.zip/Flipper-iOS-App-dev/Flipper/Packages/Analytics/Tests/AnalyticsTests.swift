import XCTest

class AnalyticsTests: XCTestCase {
    func emptyTest() {
    }
}
